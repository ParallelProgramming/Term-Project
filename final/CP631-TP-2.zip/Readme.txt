Files:
	serial-apriori.py and parallel-apriori.py are the main entry points of the program.

Folders:
	datasets - contains all datasets used for this project
	tools - has helper scripts (converters and verifier)
	output - includes all logs from sharcnet
	static - contains source code for the static parallel implementation
	dynamic- contains source code for the dynamic parallel implementation
	utils - holds the source code of commonly used methods in all three versions (serial, parallel- static and parallel-dynamic)
